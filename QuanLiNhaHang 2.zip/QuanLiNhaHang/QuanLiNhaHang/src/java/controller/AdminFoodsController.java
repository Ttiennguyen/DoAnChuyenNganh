/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package controller;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.util.Iterator;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.Part;
//import org.apache.commons.fileupload.FileItem;
//import org.apache.commons.fileupload.FileUploadException;
//import org.apache.commons.fileupload.disk.DiskFileItemFactory;
//import org.apache.commons.fileupload.servlet.ServletFileUpload;
import db.DonViTinh;
import db.DonViTinhFacade;
import db.Loai;
import db.LoaiFacade;
import db.MonAn;
import db.MonAnFacade;
import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;
import java.util.List;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.apache.tomcat.util.http.fileupload.RequestContext;

/**
 *
 * @author nguyentien
 */
@WebServlet(name = "AdminFoodsController", urlPatterns = {"/adminfoods"})
public class AdminFoodsController extends HttpServlet {

    private static final int MEMORY_THRESHOLD = 1024 * 1024 * 3;  // 3MB
    private static final int MAX_FILE_SIZE = 1024 * 1024 * 40; // 40MB
    private static final int MAX_REQUEST_SIZE = 1024 * 1024 * 50; // 50MB

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        String controller = (String) request.getAttribute("controller");
        String action = (String) request.getAttribute("action");
        MonAnFacade MAF = new MonAnFacade();
        switch (action) {
            case "index":
                try {
                    List<MonAn> list = MAF.select();
                    request.setAttribute("list", list);
                    //Hien login form
                    //Forward request & response to the main layout
                    request.getRequestDispatcher("/WEB-INF/layouts/mainAdmin.jsp").forward(request, response);
                } catch (SQLException ex) {
                    //Hien trang thong bao loi
                    ex.printStackTrace();//in thong bao loi chi tiet cho developer
                    request.setAttribute("message", ex.getMessage());
                    request.setAttribute("controller", "error");
                    request.setAttribute("action", "error");
                    request.getRequestDispatcher("/WEB-INF/layouts/mainAdmin.jsp").forward(request, response);
                }
                break;
            case "create":
                try {
                    LoaiFacade lf = new LoaiFacade();
                    List<Loai> list2 = lf.select();
                    request.setAttribute("list2", list2);
                    //
                    DonViTinhFacade DvtF = new DonViTinhFacade();
                    List<DonViTinh> list1 = DvtF.select();
                    request.setAttribute("list1", list1);
                    //
                    request.getRequestDispatcher("/WEB-INF/layouts/mainAdmin.jsp").forward(request, response);
                } catch (SQLException ex) {
                    request.setAttribute("message", ex.getMessage());
                    request.getRequestDispatcher("/WEB-INF/layouts/mainAdmin.jsp").forward(request, response);
                }
                break;

//            case "create_handler": {//Xu ly create form             
//                try {
//                    // configures upload settings
//                    DiskFileItemFactory factory = new DiskFileItemFactory();
//                    // sets memory threshold - beyond which files are stored in disk
//                    factory.setSizeThreshold(MEMORY_THRESHOLD);
//                    // sets temporary location to store files
//                    factory.setRepository(new File(System.getProperty("java.io.tmpdir")));
//
//                    ServletFileUpload upload = new ServletFileUpload(factory);
//                    // sets maximum size of upload file
//                    upload.setFileSizeMax(MAX_FILE_SIZE);
//                    // sets maximum size of request (include file + form data)
//                    upload.setSizeMax(MAX_REQUEST_SIZE);
//
//                    //Declare variables
//                    String id = null;
//                    String fileName = null;
//                    String op = null;
//                    FileItem fileItem = null;
//                    // Parse the request
//                    List<FileItem> items = null;
////                    try {
//                        items = upload.parseRequest(request);
//
//                        for (FileItem item : items) {
//                            if (item.isFormField()) {
//                                String fieldName = item.getFieldName();
//                                String fieldValue = item.getString();
//                                System.out.println(fieldName);
//                                System.out.println(fieldValue);
//                                switch (fieldName) {
//                                    case "id":
//                                        id = fieldValue;
//                                        break;
//                                    case "op":
//                                        op = fieldValue;
//                                        break;
//                                }
//                                fileName = String.format("%s.jpg", id);
//                            } else {
//                                fileItem = item;
//                            }
//                        }
//                        switch (op) {
//                            case "create":
//                                createFood();
//                                save(fileItem, fileName);
//                                //Hiển thị danh sách các mẫu tin của table toy
//                                response.sendRedirect(request.getContextPath() + "/adminfoods/index.do");
//                                break;
//                            case "cancel":
//                                //Hiển thị danh sách các mẫu tin của table toy
//                                response.sendRedirect(request.getContextPath() + "/adminfoods/index.do");
//                                break;
//                        }
////                        request.setAttribute("fileName", fileName);
////                        request.setAttribute("message", "thanh cong");
////                    } catch (Exception ex) {
////                        ex.printStackTrace();
////                        request.setAttribute("message", ex.getMessage());
////                    }
////                    request.setAttribute("message", "Uploading the image successfully.");
//                    // gửi lên
////                            String tenMonAn = request.getParameter("tenMonAn");
////                            int donGia = Integer.parseInt(request.getParameter("donGia"));
////                            String donViTinh = request.getParameter("donViTinh");
////                            String loai = request.getParameter("loai");
////                            //Tao doi tuong toy
////                            MonAn monAn = new MonAn(tenMonAn, donGia, donViTinh, loai);
////                            request.setAttribute("monAn", monAn);
////                            //
////                            LoaiFacade lf = new LoaiFacade();
////                            List<Loai> list2 = lf.select();
////                            request.setAttribute("list2", list2);
////                            //
////                            DonViTinhFacade DvtF = new DonViTinhFacade();
////                            List<DonViTinh> list1 = DvtF.select();
////                            request.setAttribute("list1", list1);
////                            //Cập nhật dữ liệu vào db
////                            MAF.create(monAn);
//                    //Hiển thị danh sách các mẫu tin của table toy
//                    //response.sendRedirect(request.getContextPath() + "/adminfoods/index.do");
//                } catch (Exception ex) {
//                    //Hien create form de nhap lai du lieu
//                    ex.printStackTrace();//in thong bao loi chi tiet cho developer
//                    request.setAttribute("action", "create");
//                    //request.setAttribute("message", ex.getMessage());
//                    request.setAttribute("message", ex.toString());
//                    request.getRequestDispatcher("/WEB-INF/layouts/mainAdmin.jsp").forward(request, response);
//                }
//
//            }
//            break;
            case "edit"://Hien form de sua du lieu
                try {
                    LoaiFacade lf = new LoaiFacade();
                    List<Loai> list2 = lf.select();
                    request.setAttribute("list2", list2);
                    //
                    DonViTinhFacade DvtF = new DonViTinhFacade();
                    List<DonViTinh> list1 = DvtF.select();
                    request.setAttribute("list1", list1);

                    //Đọc mẫu tin cần sửa vào đối tượng
                    int id = Integer.parseInt(request.getParameter("id"));
                    MonAn monAn = MAF.read(id);
                    //Lưu toy vào request để truyền cho view edit.jsp
                    request.setAttribute("monAn", monAn);
                    //Chuyển request & response đến view edit.jsp để xử ly tiếp
                    request.getRequestDispatcher("/WEB-INF/layouts/mainAdmin.jsp").forward(request, response);
                } catch (SQLException ex) {
                    //Hien trang thong bao loi
                    ex.printStackTrace();//in thong bao loi chi tiet cho developer
                    request.setAttribute("message", ex.getMessage());
                    request.setAttribute("controller", "error");
                    request.setAttribute("action", "error");
                    request.getRequestDispatcher("/WEB-INF/layouts/mainAdmin.jsp").forward(request, response);
                }
                break;
            case "edit_handler": {//Luu thong tin vao db
                String op = request.getParameter("op");
                switch (op) {
                    case "update":
                        try {
                            //Đọc dữ liệu từ client gửi lên
                            int id = Integer.parseInt(request.getParameter("id"));
                            String tenMonAn = request.getParameter("tenMonAn");
                            int donGia = Integer.parseInt(request.getParameter("donGia"));
                            String donViTinh = request.getParameter("donViTinh");
                            String loai = request.getParameter("loai");
                            //Cập nhật dữ liệu vào db
                            MonAn monAn = new MonAn(id, tenMonAn, donGia, donViTinh, loai);

                            LoaiFacade lf = new LoaiFacade();
                            List<Loai> list2 = lf.select();
                            request.setAttribute("list2", list2);
                            //
                            DonViTinhFacade DvtF = new DonViTinhFacade();
                            List<DonViTinh> list1 = DvtF.select();
                            request.setAttribute("list1", list1);

                            MAF.update(monAn);
                            //Hiển thị danh sách các mẫu tin của table toy
                            response.sendRedirect(request.getContextPath() + "/adminfoods/index.do");
                        } catch (Exception ex) {
                            //Hien trang thong bao loi
                            ex.printStackTrace();//in thong bao loi chi tiet cho developer
                            request.setAttribute("message", ex.getMessage());
                            request.setAttribute("controller", "error");
                            request.setAttribute("action", "error");
                            request.getRequestDispatcher("/WEB-INF/layouts/mainAdmin.jsp").forward(request, response);
                        }
                        break;
                    case "cancel":
                        //Hiển thị danh sách các mẫu tin của table toy
                        response.sendRedirect(request.getContextPath() + "/adminfoods/index.do");
                        break;
                }
            }
            break;
            case "delete":
                try {
                    int id = Integer.parseInt(request.getParameter("id"));
                    MAF.delete(id);

                    response.sendRedirect(request.getContextPath() + "/adminfoods/index.do");
                } catch (SQLException ex) {
                    //Hien trang thong bao loi
                    ex.printStackTrace();//in thong bao loi chi tiet cho developer
                    request.setAttribute("message", ex.getMessage());
                    request.setAttribute("controller", "error");
                    request.setAttribute("action", "error");
                    request.getRequestDispatcher("/WEB-INF/layouts/mainAdmin.jsp").forward(request, response);
                }
                break;
        }
    }

//    private void save(FileItem item, String fileName) throws Exception {
//        //lấy đường dẫn tuyệt đối của folder /images
//        //D:/.../<project-name>/build/web/images/
//        String absolutePath = getServletContext().getRealPath("/images/");
//        //Tạo đường dẫn tuyệt đối của file sẽ lưu hình        
//        //D:/.../<project-name>/build/web/images/<fileName>
//        String filePath1 = absolutePath + "\\" + fileName;
//        //D:/.../<project-name>/web/images/<fileName>
//        String filePath2 = getServletContext().getRealPath("/") + "..\\..\\web\\images\\" + fileName;
//        System.out.println(filePath1);
//        System.out.println(filePath2);
//        File file1 = new File(filePath1);
//        File file2 = new File(filePath2);
//        item.write(file1);
//        item.write(file2);
//    }

    private void createFood() throws Exception {
        HttpServletRequest request = null;
        MonAnFacade MAF = new MonAnFacade();

        // gửi lên
        String tenMonAn = request.getParameter("tenMonAn");
        int donGia = Integer.parseInt(request.getParameter("donGia"));
        String donViTinh = request.getParameter("donViTinh");
        String loai = request.getParameter("loai");
        //Tao doi tuong toy
        MonAn monAn = new MonAn(tenMonAn, donGia, donViTinh, loai);
        request.setAttribute("monAn", monAn);
        //
        LoaiFacade lf = new LoaiFacade();
        List<Loai> list2 = lf.select();
        request.setAttribute("list2", list2);
        //
        DonViTinhFacade DvtF = new DonViTinhFacade();
        List<DonViTinh> list1 = DvtF.select();
        request.setAttribute("list1", list1);                            //Cập nhật dữ liệu vào db
        MAF.create(monAn);
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
