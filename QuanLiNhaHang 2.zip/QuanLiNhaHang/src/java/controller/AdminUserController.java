/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */

package controller;

import db.Role;
import db.RoleFacade;
import db.TaiKhoan;
import db.TaiKhoanFacade;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;
import java.util.List;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author nguyentien
 */
@WebServlet(name="AdminUserController", urlPatterns={"/adminusers"})
public class AdminUserController extends HttpServlet {
   
    /** 
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code> methods.
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        String controller = (String) request.getAttribute("controller");
        String action = (String) request.getAttribute("action");
        TaiKhoanFacade TKF = new TaiKhoanFacade();
        switch (action) {
            case "index":
                try {
                List<TaiKhoan> list = TKF.select();
                request.setAttribute("list", list);
                //Hien login form
                //Forward request & response to the main layout
                request.getRequestDispatcher("/WEB-INF/layouts/mainAdmin.jsp").forward(request, response);
            } catch (SQLException ex) {
                //Hien trang thong bao loi
                ex.printStackTrace();//in thong bao loi chi tiet cho developer
                request.setAttribute("message", ex.getMessage());
                request.setAttribute("controller", "error");
                request.setAttribute("action", "error");
                request.getRequestDispatcher("/WEB-INF/layouts/mainAdmin.jsp").forward(request, response);
            }
            break;
            case "create": 
                try {
                RoleFacade rf = new RoleFacade();
                List<Role> list1 = rf.select();
                request.setAttribute("list1", list1);

                request.getRequestDispatcher("/WEB-INF/layouts/mainAdmin.jsp").forward(request, response);
            } catch (SQLException ex) {
                request.setAttribute("message", ex.getMessage());
                request.getRequestDispatcher("/WEB-INF/layouts/mainAdmin.jsp").forward(request, response);
            }
            break;
            case "create_handler": {//Xu ly create form
                String op = request.getParameter("op");
                switch (op) {
                    case "create":
                         try {
                        //Đọc dữ liệu từ client gửi lên
                        String email = request.getParameter("email");
                        String password = request.getParameter("password");
                        String fullName = request.getParameter("fullName");
                        String role = request.getParameter("role");
                        //Tao doi tuong 
                        TaiKhoan taiKhoan = new TaiKhoan(email, password, fullName, role);
                        request.setAttribute("taiKhoan", taiKhoan);
                        //
                        RoleFacade rf = new RoleFacade();
                        List<Role> list1 = rf.select();
                        request.setAttribute("list", list1);

                        TKF.create(taiKhoan);
                        //Hiển thị danh sách các mẫu tin của table toy
                        response.sendRedirect(request.getContextPath() + "/adminusers/index.do");
                    } catch (Exception ex) {
                        //Hien create form de nhap lai du lieu
                        ex.printStackTrace();//in thong bao loi chi tiet cho developer
                        request.setAttribute("action", "create");
                        request.setAttribute("message", ex.getMessage());
                        request.getRequestDispatcher("/WEB-INF/layouts/mainAdmin.jsp").forward(request, response);
                    }
                    break;
                    case "cancel":
                        //Hiển thị danh sách các mẫu tin của table toy
                        response.sendRedirect(request.getContextPath() + "/adminusers/index.do");
                        break;
                }
            }
            break;
            case "edit"://Hien form de sua du lieu
                try {
                //Đọc mẫu tin cần sửa vào đối tượng toy
                int id = Integer.parseInt(request.getParameter("id"));
                TaiKhoan taiKhoan = TKF.read(id);
                //Lưu toy vào request để truyền cho view edit.jsp
                request.setAttribute("taiKhoan", taiKhoan);

                RoleFacade rf = new RoleFacade();
                List<Role> list1 = rf.select();
                request.setAttribute("list1", list1);

                //Chuyển request & response đến view edit.jsp để xử ly tiếp
                request.getRequestDispatcher("/WEB-INF/layouts/mainAdmin.jsp").forward(request, response);
            } catch (SQLException ex) {
                //Hien trang thong bao loi
                ex.printStackTrace();//in thong bao loi chi tiet cho developer
                request.setAttribute("message", ex.getMessage());
                request.setAttribute("controller", "error");
                request.setAttribute("action", "error");
                request.getRequestDispatcher("/WEB-INF/layouts/mainAdmin.jsp").forward(request, response);
            }
            break;
            case "edit_handler": {//Luu thong tin vao db
                String op = request.getParameter("op");
                switch (op) {
                    case "update":
                        try {
                        //Đọc dữ liệu từ client gửi lên
                        int id = Integer.parseInt(request.getParameter("id"));
                        String email = request.getParameter("email");
                        String password = request.getParameter("password");
                        String fullName = request.getParameter("fullName");
                        String role = request.getParameter("role");
                        //Tao doi tuong 
                        //Cập nhật dữ liệu vào db
                        TaiKhoan taiKhoan = new TaiKhoan(id, email, password, fullName, role);
                        request.setAttribute("taiKhoan", taiKhoan);
                        RoleFacade rf = new RoleFacade();
                        List<Role> list1 = rf.select();
                        request.setAttribute("list1", list1);
                        TKF.update(taiKhoan);
                        //Hiển thị danh sách các mẫu tin của table 
                        response.sendRedirect(request.getContextPath() + "/adminusers/index.do");
                    } catch (Exception ex) {
                        //Hien trang thong bao loi
                        ex.printStackTrace();//in thong bao loi chi tiet cho developer
                        request.setAttribute("message", ex.getMessage());
                        request.setAttribute("controller", "error");
                        request.setAttribute("action", "error");
                        request.getRequestDispatcher("/WEB-INF/layouts/mainAdmin.jsp").forward(request, response);
                    }
                    break;
                    case "cancel":
                        //Hiển thị danh sách các mẫu tin của table toy
                        response.sendRedirect(request.getContextPath() + "/adminusers/index.do");
                        break;
                }
            }
            break;
            case "delete":
                try {
                int id = Integer.parseInt(request.getParameter("id"));
                TKF.delete(id);

                response.sendRedirect(request.getContextPath() + "/user/index.do");
            } catch (SQLException ex) {
                //Hien trang thong bao loi
                ex.printStackTrace();//in thong bao loi chi tiet cho developer
                request.setAttribute("message", ex.getMessage());
                request.setAttribute("controller", "error");
                request.setAttribute("action", "error");
                request.getRequestDispatcher("/WEB-INF/layouts/mainAdmin.jsp").forward(request, response);
            }
            break;
        }
    } 

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /** 
     * Handles the HTTP <code>GET</code> method.
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException {
        processRequest(request, response);
    } 

    /** 
     * Handles the HTTP <code>POST</code> method.
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException {
        processRequest(request, response);
    }

    /** 
     * Returns a short description of the servlet.
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
