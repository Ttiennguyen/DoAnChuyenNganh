/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package controller;

import db.TaiKhoanFacade;
import db.TaiKhoan;
import db.*;
import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 *
 * @author nguyentien
 */
@WebServlet(name = "TaiKhoanController", urlPatterns = {"/account"})
public class TaiKhoanController extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        String controller = (String) request.getAttribute("controller");
        String action = (String) request.getAttribute("action");
        switch (action) {
            case "login":
                //Hien login form
                //Forward request & response to the main layout
                request.getRequestDispatcher("/WEB-INF/views/account/login.jsp").forward(request, response);
                break;
            case "signUp":
                request.getRequestDispatcher("/WEB-INF/views/account/signUp.jsp").forward(request, response);
                break;
            case "login_handler":
                //Xu ly login form
                login_handler(request, response);
                //Forward request & response to the main layout
                //request.getRequestDispatcher("/WEB-INF/layouts/main.jsp").forward(request, response);
                break;
            case "signup_handler":
                signup_handler(request, response);
                break;
            case "logout":
                //Processing code here
                logout(request, response);
                //Forward request & response to the main layout
                //request.getRequestDispatcher("/WEB-INF/layouts/main.jsp").forward(request, response);
                break;
            default:
            //Show error page
        }
    }

    protected void signup_handler(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String op = request.getParameter("op");
        switch (op) {
            case "signup":
                try {
                String fullName = request.getParameter("fullName");
                String email = request.getParameter("email");
                String password = request.getParameter("password");
                TaiKhoanFacade uf = new TaiKhoanFacade();
                TaiKhoan taiKhoan = uf.signup(email, password, fullName);
                if (taiKhoan != null) {
                    //Neu dang ky thanh cong:
                    //Luu account vao session
                    HttpSession session = request.getSession();
                    session.setAttribute("taiKhoan", taiKhoan);
                    //quay ve home page
                    request.setAttribute("message", "Dang Ky khong Thanh Cong");
                    request.getRequestDispatcher("/account/signUp.do").forward(request, response);
                } else {
                    //Cho hien lai login form
                    request.setAttribute("message", "dang ky thanh cong");
                    request.getRequestDispatcher("/account/login.do").forward(request, response);
                }
            } catch (Exception ex) {
                //Cho hien lai login form
                request.setAttribute("message", ex.toString());
                request.getRequestDispatcher("/account/login.do").forward(request, response);
            }
            break;
            case "cancel":
                //quay ve home page
                request.getRequestDispatcher("/account/login.do").forward(request, response);
                break;
        }
    }

    protected void login_handler(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String op = request.getParameter("op");
        switch (op) {
            case "login":
                try {
                String email = request.getParameter("email");
                String password = request.getParameter("password");
                TaiKhoanFacade uf = new TaiKhoanFacade();
                TaiKhoan taiKhoan = uf.login(email, password);

                if (taiKhoan != null) {
                    //Neu login thanh cong:
                    //Luu account vao session
                    HttpSession session = request.getSession();
                    session.setAttribute("taiKhoan", taiKhoan);
                    //quay ve home page
                    response.sendRedirect(request.getContextPath() + "/home/index.do");
                    System.out.print("ko hiện");
                        
                } else {
                    //Cho hien lai login form
                    request.setAttribute("message", "Incorrect email or password.");
                    request.getRequestDispatcher("/account/login.do").forward(request, response);
                }

            } catch (Exception ex) {
                //Cho hien lai login form
                request.setAttribute("message", ex.toString());
                request.getRequestDispatcher("/account/login.do").forward(request, response);
            }
            break;
            case "cancel":
                //quay ve home page
                request.getRequestDispatcher("/home/index.do").forward(request, response);
                break;
            case "signup":
                request.getRequestDispatcher("/WEB-INF/views/account/signUp.jsp").forward(request, response);
                break;
        }
    }

    protected void logout(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        //Xoa session
        HttpSession session = request.getSession();
        session.invalidate();
        //Quay ve home page
        response.sendRedirect(request.getContextPath() + "/home/index.do");
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }
}
