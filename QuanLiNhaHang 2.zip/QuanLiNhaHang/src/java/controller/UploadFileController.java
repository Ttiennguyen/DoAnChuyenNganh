/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;

import db.DonViTinh;
import db.DonViTinhFacade;
import db.Loai;
import db.LoaiFacade;
import db.MonAn;
import db.MonAnFacade;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.sql.SQLException;
import java.util.List;
import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.Part;

/**
 *
 * @author Admin
 */
@WebServlet(name = "UploadFileController", urlPatterns = {"/uploadfile"})
@MultipartConfig(
        fileSizeThreshold = 1024 * 1024 * 2,//2MB
        maxFileSize = 1024 * 1024 * 5,//5MB
        maxRequestSize = 1024 * 1024 * 10)//10MB
public class UploadFileController extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        create_handler(request, response);
    }

    protected void create_handler(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        MonAnFacade MAF = new MonAnFacade();
        String tenMonAn = request.getParameter("tenMonAn");
        int donGia = Integer.parseInt(request.getParameter("donGia"));
        String donViTinh = request.getParameter("donViTinh");
        String loai = request.getParameter("loai");
        //Lấy thông tin từ client
        try {
            LoaiFacade lf = new LoaiFacade();
            List<Loai> list2 = lf.select();
            request.setAttribute("list2", list2);
            //
            DonViTinhFacade DvtF = new DonViTinhFacade();
            List<DonViTinh> list1 = DvtF.select();
            request.setAttribute("list1", list1);
        } catch (SQLException ex) {
            request.setAttribute("message", ex.getMessage());
        }
        String op = request.getParameter("op");
        String id = request.getParameter("id");
        MonAn monAn = new MonAn(tenMonAn, donGia, donViTinh, loai);
        request.setAttribute("monAn", monAn);
        switch (op) {
            case "create":
                String fileName = String.format("%s.jpg", id);
                //Lấy tên file được upload
                Part filePart = request.getPart("file");
                String submittedFileName = filePart.getSubmittedFileName();
                System.out.println("submittedFileName: " + submittedFileName);
                if (id.trim().equals("") || submittedFileName.trim().equals("")) {
                    //thông báo lỗi nếu để trắng toàn bộ 
                    request.setAttribute("message", "File name can not be blank."); 
                    request.getRequestDispatcher("/adminfoods/create.do").forward(request, response);
                } else {
                    //lấy đường dẫn tuyệt đối của folder /images
                    //D:/.../upload-images-gf/build/web/images/
                    String absolutePath = getServletContext().getRealPath("/images/");
                    //Tạo đường dẫn tuyệt đối của file sẽ lưu hình        
                    //D:/.../upload-images-gf/build/web/images/<fileName>
                    String filePath1 = absolutePath + "\\" + fileName;
                    //D:/.../upload-images-gf/web/images/<fileName>
                    String filePath2 = getServletContext().getRealPath("/") + "../../web/images/" + fileName;
                    System.out.println(filePath1);
                    System.out.println(filePath2);

                    try (OutputStream out1 = new FileOutputStream(new File(filePath1)); OutputStream out2 = new FileOutputStream(new File(filePath2)); InputStream in = filePart.getInputStream()) {

                        int read = 0;
                        final byte[] bytes = new byte[1024];

                        //Đọc dữ liệu từ file được upload để lưu vào filePath
                        while ((read = in.read(bytes)) != -1) {
                            out1.write(bytes, 0, read);
                            out2.write(bytes, 0, read);
                        }
                        MAF.create(monAn);
                        request.setAttribute("message", "Uploading the image successfully.");
                        request.setAttribute("fileName", fileName);
                        request.getRequestDispatcher("/adminfoods/index.do").forward(request, response);
                    } catch (Exception ex) {
                        //thông báo lỗi
                        request.setAttribute("message", ex.toString());
                        request.getRequestDispatcher("/adminfoods/create.do").forward(request, response);
                    }
                }
            break;
            case "cancel":
                //Hiển thị danh sách các mẫu tin của table toy
                request.getRequestDispatcher("/adminfoods/index.do").forward(request, response);
            break;
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
