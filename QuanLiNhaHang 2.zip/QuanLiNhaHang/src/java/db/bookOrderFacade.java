/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package db;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author nguyentien
 */
public class bookOrderFacade {

    public List<BookOrder> select() throws SQLException {
        List<BookOrder> list = null;
        //Tạo connection để kết nối vào DBMS
        Connection con = DBContext.getConnection();
        //Tạo đối tượng statement
        Statement stm = con.createStatement();
        //Thực thi lệnh SELECT
        ResultSet rs = stm.executeQuery("select * from BookTable");
        list = new ArrayList<>();
        while (rs.next()) {
            BookOrder bookOrder = new BookOrder();
            bookOrder.setId(rs.getInt("id"));
            bookOrder.setName(rs.getString("name"));
            bookOrder.setEmail(rs.getString("email"));
            bookOrder.setPhoneNumber(rs.getString("phoneNumber"));
            bookOrder.setAmountPeople(rs.getInt("amountPeople"));
            bookOrder.setDateandTime(rs.getDate("dateandTime"));
            // add thêm phần id rồi viết tiếp
            list.add(bookOrder);
        }
        con.close();
        return list;
    }

    public void create(BookOrder bookOrder) throws SQLException {
        //Tạo connection để kết nối vào DBMS
        Connection con = DBContext.getConnection();
        //Tạo đối tượng PreparedStatement
        PreparedStatement stm = con.prepareStatement("insert BookTable values(?, ?, ?, ?, ?)");
        stm.setString(1, bookOrder.getName());
        stm.setString(2,bookOrder.getEmail());
        stm.setString(3,bookOrder.getPhoneNumber());
        stm.setInt(4, bookOrder.getAmountPeople());
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        stm.setString(5, sdf.format(bookOrder.getDateandTime()));
        //Thực thi lệnh sql
        int count = stm.executeUpdate();       
        //Đóng kết nối
        con.close();
    }
    
    public BookOrder read(int id) throws SQLException {
        BookOrder bookOrder = null;
        //Tạo connection để kết nối vào DBMS
        Connection con = DBContext.getConnection();
        //Tạo đối tượng PreparedStatement
        PreparedStatement stm = con.prepareStatement("select * from BookOrder where id = ?");
        stm.setInt(1, id);
        //Thực thi lệnh sql
        ResultSet rs = stm.executeQuery();
        //Load dữ liệu vào đối tượng toy nếu có
        if (rs.next()){
            bookOrder = new BookOrder();
            bookOrder.setId(rs.getInt("id"));
            bookOrder.setName(rs.getString("fullName"));
            bookOrder.setEmail(rs.getString("email"));
            bookOrder.setPhoneNumber(rs.getString("phone"));
            bookOrder.setAmountPeople(rs.getInt("amount"));
            bookOrder.setDateandTime(rs.getDate("datetime"));           
        }
        //Đóng kết nối
        con.close();
        return bookOrder;
    }
    
    public void delete(int id) throws SQLException {
        //Tạo connection để kết nối vào DBMS
        Connection con = DBContext.getConnection();
        //Tạo đối tượng PreparedStatement
        PreparedStatement stm = con.prepareStatement("delete from BookTable where id = ?");
        stm.setInt(1, id);
        //Thực thi lệnh sql
        int count = stm.executeUpdate();
        con.close();
    }
}
