/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package db;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;

/**
 *
 * @author nguyentien
 */
public class MonAnFacade {
    
     public List<MonAn> select() throws SQLException {
        List<MonAn> list = null;
        //Tạo connection để kết nối vào DBMS
        Connection con = DBContext.getConnection();
        //Tạo đối tượng statement
        Statement stm = con.createStatement();
        //Thực thi lệnh SELECT
        ResultSet rs = stm.executeQuery("select * from MonAn");
        list = new ArrayList<>();
        while (rs.next()) {
            MonAn monAn = new MonAn();
            monAn.setId(rs.getInt("id"));
            monAn.setTenMonAn(rs.getString("tenMonAn"));
            monAn.setDonGia(rs.getInt("donGia"));
            monAn.setDonViTinh(rs.getString("donViTinh"));
            monAn.setLoai(rs.getNString("loai"));
            // add thêm phần id rồi viết tiếp
            list.add(monAn);
        }
        con.close();
        return list;
    }
     
      public void create(MonAn monAn) throws SQLException {
        //Tạo connection để kết nối vào DBMS
        Connection con = DBContext.getConnection();
        //Tạo đối tượng PreparedStatement
        PreparedStatement stm = con.prepareStatement("insert MonAn values(?, ?, ?, ?)");
        stm.setString(1, monAn.getTenMonAn());
        stm.setInt(2, monAn.getDonGia());
        stm.setString(3, monAn.getDonViTinh());
        stm.setString(4, monAn.getLoai());        
        //Thực thi lệnh sql
        int count = stm.executeUpdate();       
        //Đóng kết nối
        con.close();
    }
      
      public MonAn read(int id) throws SQLException {
        MonAn monAn = null;
        //Tạo connection để kết nối vào DBMS
        Connection con = DBContext.getConnection();
        //Tạo đối tượng PreparedStatement
        PreparedStatement stm = con.prepareStatement("select * from MonAn where id = ?");
        stm.setInt(1, id);
        //Thực thi lệnh sql
        ResultSet rs = stm.executeQuery();
        //Load dữ liệu vào đối tượng toy nếu có
        if (rs.next()){
            monAn = new MonAn();
            monAn.setId(rs.getInt("id"));
            monAn.setTenMonAn(rs.getString("tenMonAn"));
            monAn.setDonGia(rs.getInt("donGia"));
            monAn.setDonViTinh(rs.getString("donViTinh"));
            monAn.setLoai(rs.getString("loai"));
            
        }
        //Đóng kết nối
        con.close();
        return monAn;
    }
    
      public void update(MonAn monAn) throws SQLException {
        //Tạo connection để kết nối vào DBMS
        Connection con = DBContext.getConnection();
        //Tạo đối tượng PreparedStatement
        PreparedStatement stm = con.prepareStatement("update MonAn set TenMonAn = ?, DonGia = ?, DonViTinh = ?, Loai = ? where id = ?");
        stm.setString(1, monAn.getTenMonAn());
        stm.setInt(2, monAn.getDonGia());
        stm.setString(3, monAn.getDonViTinh());
        stm.setString(4, monAn.getLoai());
        stm.setInt(5, monAn.getId());
        //Thực thi lệnh sql
        int count = stm.executeUpdate();       
        //Đóng kết nối
        con.close();
    }

    public void delete(int id) throws SQLException {
        //Tạo connection để kết nối vào DBMS
        Connection con = DBContext.getConnection();
        //Tạo đối tượng PreparedStatement
        PreparedStatement stm = con.prepareStatement("delete from monAn where id = ?");
        stm.setInt(1, id);
        //Thực thi lệnh sql
        int count = stm.executeUpdate();
        con.close();
    }
    
}
