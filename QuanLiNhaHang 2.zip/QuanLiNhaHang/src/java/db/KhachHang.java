/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package db;

/**
 *
 * @author nguyentien
 */
public class KhachHang {
    
    private int id;
    private String ho;
    private String ten;
    private String soDienThoai;
    private String email;
    private int taiKhoanId;

    public KhachHang() {
    }

    public KhachHang(int id, String ho, String ten, String soDienThoai, String email,int taiKhoanId) {
        this.id = id;
        this.ho = ho;
        this.ten = ten;
        this.soDienThoai = soDienThoai;
        this.email = email;
        this.taiKhoanId = taiKhoanId;
    }

    public int getId() {
        return id;
    }

    public String getHo() {
        return ho;
    }

    public String getTen() {
        return ten;
    }

    public String getSoDienThoai() {
        return soDienThoai;
    }

    public String getEmail() {
        return email;
    }

    public int getTaiKhoanId() {
        return taiKhoanId;
    }
    

    public void setId(int id) {
        this.id = id;
    }

    public void setHo(String ho) {
        this.ho = ho;
    }

    public void setTen(String ten) {
        this.ten = ten;
    }

    public void setSoDienThoai(String soDienThoai) {
        this.soDienThoai = soDienThoai;
    }

    public void setEmail(String Email) {
        this.email = Email;
    }

    public void setTaiKhoanId(int taiKhoanId) {
        this.taiKhoanId = taiKhoanId;
    }
   
    
}
