/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package db;

import hash.Hasher;
import java.security.NoSuchAlgorithmException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author nguyentien
 */
public class TaiKhoanFacade {
    
      public TaiKhoan login(String email, String password) throws SQLException, NoSuchAlgorithmException {
        TaiKhoan taiKhoan = null;
        //Tạo connection để kết nối vào DBMS
        Connection con = DBContext.getConnection();
        //Tạo đối tượng PreparedStatement
        PreparedStatement stm = con.prepareStatement("select * from taikhoan where Email = ? and Password = ?");
        stm.setString(1, email);
        stm.setString(2, Hasher.hash(password));
        //Thực thi lệnh sql
        ResultSet rs = stm.executeQuery();
        //Load dữ liệu vào đối tượng nếu có
        if (rs.next()){
            taiKhoan = new TaiKhoan();
            taiKhoan.setId(rs.getInt("id"));
            taiKhoan.setEmail(rs.getString("email"));
            taiKhoan.setPassword(rs.getString("password"));
            taiKhoan.setFullName(rs.getString("fullName"));
            taiKhoan.setRole(rs.getString("role"));
        }
        //Đóng kết nối
        con.close();
        return taiKhoan;
    }
      
    public TaiKhoan signup(String email,String password,String fullName) throws SQLException, NoSuchAlgorithmException {
        TaiKhoan taiKhoan = null;
        
        String role ="USER";
        Connection con = DBContext.getConnection();
        
        PreparedStatement stm = con.prepareStatement("insert TaiKhoan values(?, ?, ?, ?)");
        stm.setString(1,email);
        stm.setString(2, Hasher.hash(password));
        stm.setString(3, fullName);
        stm.setString(4,role);
        
        int count = stm.executeUpdate(); 
        //Đóng kết nối
        con.close();
        return taiKhoan;
        
    } 
    
    public List<TaiKhoan> select() throws SQLException {
        List<TaiKhoan> list = null;
        //Tạo connection để kết nối vào DBMS
        Connection con = DBContext.getConnection();
        //Tạo đối tượng statement
        Statement stm = con.createStatement();
        //Thực thi lệnh SELECT
        ResultSet rs = stm.executeQuery("select * from TaiKhoan");
        list = new ArrayList<>();
        while (rs.next()) {
            TaiKhoan taiKhoan = new TaiKhoan();
            taiKhoan.setId(rs.getInt("id"));
            taiKhoan.setEmail(rs.getString("email"));
            taiKhoan.setPassword(rs.getString("password"));
            taiKhoan.setFullName(rs.getString("fullName"));
            taiKhoan.setRole(rs.getString("role"));
            // add thêm phần id rồi viết tiếp
            list.add(taiKhoan);
        }
        con.close();
        return list;
    }
    
    public TaiKhoan read(int id) throws SQLException {
        TaiKhoan taiKhoan = null;
        //Tạo connection để kết nối vào DBMS
        Connection con = DBContext.getConnection();
        //Tạo đối tượng PreparedStatement
        PreparedStatement stm = con.prepareStatement("select * from TaiKhoan where id = ?");
        stm.setInt(1, id);
        //Thực thi lệnh sql
        ResultSet rs = stm.executeQuery();
        //Load dữ liệu vào đối tượng toy nếu có
        if (rs.next()){
           taiKhoan = new TaiKhoan();
           taiKhoan.setId(rs.getInt("id"));
           taiKhoan.setEmail(rs.getString("email"));
           taiKhoan.setPassword(rs.getString("password"));
           taiKhoan.setFullName(rs.getString("fullName"));
           taiKhoan.setRole(rs.getString("role"));
            
        }
        //Đóng kết nối
        con.close();
        return taiKhoan;
    }
    
    public void create(TaiKhoan taiKhoan) throws SQLException, NoSuchAlgorithmException {
         //Tạo connection để kết nối vào DBMS
        Connection con = DBContext.getConnection();
        //Tạo đối tượng PreparedStatement
        PreparedStatement stm = con.prepareStatement("insert TaiKhoan values(?, ?, ?, ?)");
        stm.setString(1,taiKhoan.getEmail());
        stm.setString(2, Hasher.hash(taiKhoan.getPassword()));
        stm.setString(3, taiKhoan.getFullName());
        stm.setString(4,taiKhoan.getRole());
          
        //Thực thi lệnh sql
        int count = stm.executeUpdate();       
        //Đóng kết nối
        con.close();
    }
    
    public void update(TaiKhoan taiKhoan) throws SQLException, NoSuchAlgorithmException {
        //Tạo connection để kết nối vào DBMS
        Connection con = DBContext.getConnection();
        //Tạo đối tượng PreparedStatement
        PreparedStatement stm = con.prepareStatement("update TaiKhoan set Email = ?, Password = ?, fullName = ?, Role = ? where id = ?");
        stm.setString(1,taiKhoan.getEmail());
        stm.setString(2, Hasher.hash(taiKhoan.getPassword()));
        stm.setString(3, taiKhoan.getFullName());
        stm.setString(4,taiKhoan.getRole());
        stm.setInt(5, taiKhoan.getId());
        //Thực thi lệnh sql
        int count = stm.executeUpdate();       
        //Đóng kết nối
        con.close();
    }
    
     public void delete(int id) throws SQLException {
        //Tạo connection để kết nối vào DBMS
        Connection con = DBContext.getConnection();
        //Tạo đối tượng PreparedStatement
        PreparedStatement stm = con.prepareStatement("delete from TaiKhoan where id = ?");
        stm.setInt(1, id);
        //Thực thi lệnh sql
        int count = stm.executeUpdate();
        con.close();
    }
}
