/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package db;

import java.util.Date;

/**
 *
 * @author nguyentien
 */
public class BookOrder {
    
    private int id;
    private String name;
    private String email;
    private String phoneNumber;
    private int amountPeople;
    private Date dateandTime;

    public BookOrder() {
    }

    public int getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public String getEmail() {
        return email;
    }

    public String getPhoneNumber() {
        return phoneNumber;
    }


    public void setId(int id) {
        this.id = id;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }

    public int getAmountPeople() {
        return amountPeople;
    }

    public Date getDateandTime() {
        return dateandTime;
    }

    public void setAmountPeople(int amountPeople) {
        this.amountPeople = amountPeople;
    }

    public void setDateandTime(Date dateandTime) {
        this.dateandTime = dateandTime;
    }
    
     public BookOrder(int id, String name, String email, String phoneNumber, int amountPeople, Date dateandTime) {
        this.id = id;
        this.name = name;
        this.email = email;
        this.phoneNumber = phoneNumber;
        this.amountPeople = amountPeople;
        this.dateandTime = dateandTime;
    }

    public BookOrder(String name, String email, String phoneNumber, int amountPeople, Date dateandTime) {
        this.name = name;
        this.email = email;
        this.phoneNumber = phoneNumber;
        this.amountPeople = amountPeople;
        this.dateandTime = dateandTime;
    }
    
    
}
