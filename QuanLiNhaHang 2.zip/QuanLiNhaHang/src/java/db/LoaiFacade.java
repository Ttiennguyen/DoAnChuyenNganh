/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package db;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;


/**
 *
 * @author nguyentien
 */
public class LoaiFacade {
    
    public List<Loai> select() throws SQLException {
        List<Loai> list2 = null;
        //Tạo connection để kết nối vào DBMS
        Connection con = DBContext.getConnection();
        //Tạo đối tượng statement
        Statement stm = con.createStatement();
        //Thực thi lệnh SELECT
        ResultSet rs = stm.executeQuery("select * from Loai");
        list2 = new ArrayList<>();
        while (rs.next()) {
            Loai loai = new Loai();
            loai.setId(rs.getString("id"));
            loai.setName(rs.getString("name"));
            list2.add(loai);
        }
        con.close();
        return list2;
    }
    
}
    

