/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package db;

import hash.Hasher;
import java.security.NoSuchAlgorithmException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

/**
 *
 * @author nguyentien
 */
public class TaiKhoanFacade {
    
      public TaiKhoan login(String email, String password) throws SQLException, NoSuchAlgorithmException {
        TaiKhoan taiKhoan = null;
        //Tạo connection để kết nối vào DBMS
        Connection con = DBContext.getConnection();
        //Tạo đối tượng PreparedStatement
        PreparedStatement stm = con.prepareStatement("select * from taikhoan where Email = ? and Password = ?");
        stm.setString(1, email);
        stm.setString(2, Hasher.hash(password));
        //Thực thi lệnh sql
        ResultSet rs = stm.executeQuery();
        //Load dữ liệu vào đối tượng nếu có
        if (rs.next()){
            taiKhoan = new TaiKhoan();
            taiKhoan.setId(rs.getInt("id"));
            taiKhoan.setEmail(rs.getString("email"));
            taiKhoan.setPassword(rs.getString("password"));
            taiKhoan.setFullName(rs.getString("fullName"));
            taiKhoan.setRole(rs.getString("role"));
        }
        //Đóng kết nối
        con.close();
        return taiKhoan;
    }

}
