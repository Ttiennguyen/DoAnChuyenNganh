/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package db;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author nguyentien
 */
public class DonViTinhFacade {
    
    public List<DonViTinh> select() throws SQLException {
        List<DonViTinh> list1 = null;
        //Tạo connection để kết nối vào DBMS
        Connection con = DBContext.getConnection();
        //Tạo đối tượng statement
        Statement stm = con.createStatement();
        //Thực thi lệnh SELECT
        ResultSet rs = stm.executeQuery("select * from DonViTinh");
        list1 = new ArrayList<>();
        while (rs.next()) {
            DonViTinh donViTinh = new DonViTinh();
            donViTinh.setId(rs.getString("id"));
            donViTinh.setName(rs.getString("name"));
            list1.add(donViTinh);
        }
        con.close();
        return list1;
    }
    
}
