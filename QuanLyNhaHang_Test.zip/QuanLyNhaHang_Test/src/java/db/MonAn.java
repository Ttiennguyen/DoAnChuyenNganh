/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package db;

import java.awt.image.BufferedImage;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import javax.imageio.ImageIO;

/**
 *
 * @author nguyentien
 */
public class MonAn {
    
   private int id;
   private byte[] phoTo;
   private String tenMonAn;
   private int donGia;
   private String donViTinh;
   private String loai;

    public MonAn() {
    }

    public MonAn(int id, String tenMonAn, int donGia, String donViTinh, String loai) {
        this.id = id;
        this.tenMonAn = tenMonAn;
        this.donGia = donGia;
        this.donViTinh = donViTinh;
        this.loai = loai;
    }
    
    public MonAn(String tenMonAn, int donGia, String donViTinh, String loai) {
        this.tenMonAn = tenMonAn;
        this.donGia = donGia;
        this.donViTinh = donViTinh;
        this.loai = loai;
    }

    public MonAn(byte[] phoTo, String tenMonAn, int donGia, String donViTinh, String loai) {
        this.phoTo = phoTo;
        this.tenMonAn = tenMonAn;
        this.donGia = donGia;
        this.donViTinh = donViTinh;
        this.loai = loai;
    }

    public MonAn(int id, byte[] phoTo, String tenMonAn, int donGia, String donViTinh, String loai) {
        this.id = id;
        this.phoTo = phoTo;
        this.tenMonAn = tenMonAn;
        this.donGia = donGia;
        this.donViTinh = donViTinh;
        this.loai = loai;
    }

    public byte[] getPhoTo() {
        return phoTo;
    }

   public void setPhoTo(BufferedImage image) throws IOException {
    ByteArrayOutputStream baos = new ByteArrayOutputStream();
    ImageIO.write(image, "jpg", baos);
    baos.flush();
    this.phoTo = baos.toByteArray();
    baos.close();
}

   
    public int getId() {
        return id;
    }

    public String getTenMonAn() {
        return tenMonAn;
    }

    public int getDonGia() {
        return donGia;
    }

    public String getDonViTinh() {
        return donViTinh;
    }

    public String getLoai() {
        return loai;
    }

    public void setId(int id) {
        this.id = id;
    }

    public void setTenMonAn(String tenMonAn) {
        this.tenMonAn = tenMonAn;
    }

    public void setDonGia(int donGia) {
        this.donGia = donGia;
    }

    public void setDonViTinh(String donViTinh) {
        this.donViTinh = donViTinh;
    }

    public void setLoai(String loai) {
        this.loai = loai;
    }
    
   
}
