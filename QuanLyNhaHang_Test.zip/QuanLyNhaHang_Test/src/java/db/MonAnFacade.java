/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package db;

import java.awt.image.BufferedImage;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import javax.imageio.ImageIO;

/**
 *
 * @author nguyentien
 */
public class MonAnFacade {
    
    
    
    public List<MonAn> select() throws SQLException, IOException {
    List<MonAn> list = null;
    //Tạo connection để kết nối vào DBMS
    Connection con = DBContext.getConnection();
    //Tạo đối tượng statement
    Statement stm = con.createStatement();
    //Thực thi lệnh SELECT
    ResultSet rs = stm.executeQuery("select * from MonAn");
    list = new ArrayList<>();
    while (rs.next()) {
       MonAn monAn = new MonAn();
       monAn.setId(rs.getInt("id"));
       monAn.setTenMonAn(rs.getString("tenMonAn"));
       monAn.setDonGia(rs.getInt("donGia"));
       monAn.setDonViTinh(rs.getString("donViTinh"));
       monAn.setLoai(rs.getString("loai"));
       byte[] imageBytes = rs.getBytes("phoTo");
       BufferedImage image = ImageIO.read(new ByteArrayInputStream(imageBytes));
       monAn.setPhoTo(image);
    }
    con.close();
    return list;
}

     
    public void create(MonAn monAn) throws SQLException, IOException {
    // Tạo connection để kết nối vào DBMS
    Connection con = DBContext.getConnection();
    
    
    // Đọc dữ liệu ảnh từ file
    FileInputStream inputStream = new FileInputStream(new File("/Users/nguyentien/Desktop/"));
    ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
    byte[] buffer = new byte[4096];
    int bytesRead;
    while ((bytesRead = inputStream.read(buffer)) != -1) {
        outputStream.write(buffer, 0, bytesRead);
    }
    byte[] imageBytes = outputStream.toByteArray();

    // Tạo đối tượng PreparedStatement
    PreparedStatement stm = con.prepareStatement("INSERT INTO MonAn (tenMonAn, donGia, donViTinh, loai, phoTo) VALUES (?, ?, ?, ?, ?)");
    stm.setString(1, monAn.getTenMonAn());
    stm.setInt(2, monAn.getDonGia());
    stm.setString(3, monAn.getDonViTinh());
    stm.setString(4, monAn.getLoai());
    stm.setBytes(5, imageBytes);
    
    // Thực thi lệnh sql
    int count = stm.executeUpdate();       
    
    // Đóng kết nối
    con.close();
}
      
    public MonAn read(int id) throws SQLException {
    MonAn monAn = null;
    //Tạo connection để kết nối vào DBMS
    Connection con = DBContext.getConnection();
    //Tạo đối tượng PreparedStatement
    PreparedStatement stm = con.prepareStatement("select * from MonAn where id = ?");
    stm.setInt(1, id);
    //Thực thi lệnh sql
    ResultSet rs = stm.executeQuery();
    //Load dữ liệu vào đối tượng toy nếu có
    if (rs.next()){
        monAn = new MonAn();
        monAn.setId(rs.getInt("id"));
        monAn.setTenMonAn(rs.getString("tenMonAn"));
        monAn.setDonGia(rs.getInt("donGia"));
        monAn.setDonViTinh(rs.getString("donViTinh"));
        monAn.setLoai(rs.getString("loai"));
        // Đọc dữ liệu ảnh từ ResultSet
        byte[] imageBytes = rs.getBytes("phoTo");
        if (imageBytes != null) {
            try {
                BufferedImage image = ImageIO.read(new ByteArrayInputStream(imageBytes));
                monAn.setPhoTo(image);
            } catch (IOException ex) {
                System.err.println("Error reading image from byte array: " + ex.getMessage());
            }
        }
    }
    //Đóng kết nối
    con.close();
    return monAn;
}

    
    public void update(MonAn monAn) throws SQLException, IOException {
    //Tạo connection để kết nối vào DBMS
    Connection con = DBContext.getConnection();
    //Tạo đối tượng PreparedStatement
    PreparedStatement stm = con.prepareStatement("update MonAn set TenMonAn = ?, DonGia = ?, DonViTinh = ?, Loai = ?, PhoTo = ?  where id = ?");
    stm.setString(1, monAn.getTenMonAn());
    stm.setInt(2, monAn.getDonGia());
    stm.setString(3, monAn.getDonViTinh());
    stm.setString(4, monAn.getLoai());

    // Đọc dữ liệu ảnh từ file
    FileInputStream inputStream = new FileInputStream(new File("/Users/nguyentien/Desktop/image.png"));
    ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
    byte[] buffer = new byte[4096];
    int bytesRead;
    while ((bytesRead = inputStream.read(buffer)) != -1) {
        outputStream.write(buffer, 0, bytesRead);
    }
    byte[] imageBytes = outputStream.toByteArray();
    stm.setBytes(5, imageBytes);

    stm.setInt(6, monAn.getId());
    //Thực thi lệnh sql
    int count = stm.executeUpdate();       
    //Đóng kết nối
    con.close();
}
    


    public void delete(int id) throws SQLException {
        //Tạo connection để kết nối vào DBMS
        Connection con = DBContext.getConnection();
        //Tạo đối tượng PreparedStatement
        PreparedStatement stm = con.prepareStatement("delete from monAn where id = ?");
        stm.setInt(1, id);
        //Thực thi lệnh sql
        int count = stm.executeUpdate();
        con.close();
    }
    
}
