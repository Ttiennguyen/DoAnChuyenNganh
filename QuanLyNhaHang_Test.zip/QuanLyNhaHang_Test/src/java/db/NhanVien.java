/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package db;

/**
 *
 * @author nguyentien
 */
public class NhanVien {
    
    private int id;
    private String ho;
    private String ten;
    private String soDienThoai;
    private String Email;
    private String chucVu;
    private String luong;

    public NhanVien(int id, String ho, String ten, String soDienThoai, String Email, String chucVu, String luong) {
        this.id = id;
        this.ho = ho;
        this.ten = ten;
        this.soDienThoai = soDienThoai;
        this.Email = Email;
        this.chucVu = chucVu;
        this.luong = luong;
    }

    public NhanVien() {
    }

    public int getId() {
        return id;
    }

    public String getHo() {
        return ho;
    }

    public String getTen() {
        return ten;
    }

    public String getSoDienThoai() {
        return soDienThoai;
    }

    public String getEmail() {
        return Email;
    }

    public String getChucVu() {
        return chucVu;
    }

    public String getLuong() {
        return luong;
    }

    public void setId(int id) {
        this.id = id;
    }

    public void setHo(String ho) {
        this.ho = ho;
    }

    public void setTen(String ten) {
        this.ten = ten;
    }

    public void setSoDienThoai(String soDienThoai) {
        this.soDienThoai = soDienThoai;
    }

    public void setEmail(String Email) {
        this.Email = Email;
    }

    public void setChucVu(String chucVu) {
        this.chucVu = chucVu;
    }

    public void setLuong(String luong) {
        this.luong = luong;
    }
    
    
}
