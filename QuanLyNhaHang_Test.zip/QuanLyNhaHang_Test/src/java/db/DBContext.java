
/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package db;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/**
 *
 * @author nguyentien
 */
public class DBContext {
     public static Connection getConnection() throws SQLException{
        String url = "jdbc:sqlserver://localhost;databaseName=QuanLiNhaHangTest1;user=sa;password=123456aA@$";
        Connection con = null;
        try{
            //Loading a driver
            Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
            //Creating a connection
            con =DriverManager.getConnection(url);
        } catch (Exception ex) {
            ex.printStackTrace();
            //Gay ra SQLException
            throw new SQLException(ex.getMessage());
        }
        return con;
    }
}
